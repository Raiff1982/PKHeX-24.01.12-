﻿namespace PKHeX.Core.Injection
{
    public enum LiveHeXValidation
    {
        None = 0,
        Botbase = 1,
        BlankSAV = 2,
        GameVersion = 3,
        RAMShift = 4,
    }
}
