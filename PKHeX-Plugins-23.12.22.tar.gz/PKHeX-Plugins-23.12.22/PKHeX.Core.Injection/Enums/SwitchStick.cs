﻿namespace PKHeX.Core.Injection
{
    /// <summary>
    /// Controller Stick differentiation
    /// </summary>
    public enum SwitchStick
    {
        LEFT,
        RIGHT,
    }
}
